## {{administrate}}
アドミニストレイト


**FAM**
P: {{1::administrator}}
A: {{1::administrate}}
R: {{1::asministaration}}
Q: {{1::administrative}}
S: {{1::administratively}} 

**MULTI**
1. to {{2::administrate}} sth
2. political {{2::administration}}
3. work as an {{2::administrator}}
4. {{2::administrative}} costs
5. {{2::administrative}} assistant
6. {{2::admin}}

**SYN**
1. {{3::lead}}
2. {{3::organize}}
3. {{3::run}}

**EX**
1. His office is in charge of {{4::administrating}} local volunteer activitis. 
2.{{4::Administrative}} costs are more expensive in bigger cities.
3. The biggest ploblem in her work is too mush {{4::admin}}.
---
