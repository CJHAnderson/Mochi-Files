## {{consultant}}
コンサルタント


**FAM**
P: {{1::consultant}}
A: {{1::consult}}
R: {{1::consultation}}
Q: {{1::consultative}}
S: {{1::consultancy}} 

**MULTI**
1. {{2::consult}} sb about sth
2. a top {{2::consultant}}
3. sb {{2::consults}} for sth
4. a follow-up {{2::consultation}}
5. decide sth after {{2::consultation}} with sb
6. a {{2::consultative}} process

**SYN**
1. {{3::discuss}}
2. {{3::get advice}}
3. {{3::ask permission}}

**EX**
1. He {{4::consulted}} a financial expert about his pension problem. 
2. I can't believe you sold the car without {{4::consulting}} me. 
3. She works for a {{4::consultative}} committee that promotes SDGs.
---
