## {{estimate}}
エスティメイト


**FAM**
P: {{1::estimator}}
A: {{1::estimate}}
R: {{1::estimate}}
Q: {{1:: X }}
S: {{1:: X }} 

**MULTI**
1. {{2::estimate}} sth
2. ask for an {{2::estimate}}
3. a rough {{2::estimate}}
4. to give / provide an {{2::estimate}}
5. sb {{2::estimates}} that -
6. pad an {{2::estimate}}

**SYN**
1. {{3::calculate}}
2. {{3::guess}}
3. {{3::suggest a price}}

**EX**
1. Scientists {{4::estimate}} that the volcano will erupt in the next 10 years. 
2. He works as an {{4::estimator}} for a large insurance company. 
3. We asked three companies for {{4::estimates}} for the repair work.
---
