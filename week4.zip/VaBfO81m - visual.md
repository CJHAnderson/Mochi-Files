## {{visual}}
ヴィジュアル


**FAM**
P: {{1:: X }}
A: {{1::visualize}}
R: {{1::visuals}}
Q: {{1::visual}}
S: {{1::visually}} 

**MULTI**
1. {{2::visual}} aids
2. {{2::visual}} effects
3. {{2::visualize}} sth
4. {{2::visualize}} sb doing sth
5. {{2::visually}} impaired
6. {{2::visualize}} how / what

**SYN**
1. {{3::design}}
2. {{3::attractiveness}}
3. {{3::imagine}}

**EX**
1. She created the most {{4::visually}} interesting site in the internet. 
2. Students were asked to {{4::visualize}} their future goals. 
3. He is a good talker, but uses poor {{4::visuals}}.
---
